import json
from ..state import PipelineState, ExtractedModel
from ..tools.utils import authors_to_list, normalize_month_field, normalize_text, fingerprint_state

# ---------------------------------------------------------------------
# Lock configuration
# ---------------------------------------------------------------------
# Never let LLM override authoritative factual fields once set
# (Title and authors are intentionally unlocked to allow LLM-based normalization)
_LOCK_ALWAYS = {"doi", "year", "month", "pages"}  # factual fields stay locked
_LOCK_IF_PRESENT = {"journal_name", "journal_abbrev", "conference_name", "volume", "issue"}


def _coerce_year(y: str) -> str:
    """Extract a 4-digit year from a messy string."""
    y = normalize_text(y)
    if len(y) >= 4:
        for i in range(len(y) - 3):
            seg = y[i:i + 4]
            if seg.isdigit() and (1800 <= int(seg) <= 2100):
                return seg
    return ""


# ---------------------------------------------------------------------
# Main LLM correction function
# ---------------------------------------------------------------------
async def llm_correct(state: PipelineState) -> PipelineState:
    """
    Main correction node. Uses the LLM to clean up metadata,
    allowing intelligent title and author normalization while
    locking factual fields (DOI, year, month, pages).
    """
    ref = state["reference"]
    ex = state["extracted"]
    ver = state.get("verification") or {}
    llm = state["_llm"]

    # Authoritative values from consensus or online metadata
    best = state.get("best") or {}

    # Build lock set dynamically from known best values
    lock_fields = set()
    for k in _LOCK_ALWAYS:
        if normalize_text(best.get(k)):
            lock_fields.add(k)
    for k in _LOCK_IF_PRESENT:
        if normalize_text(best.get(k)):
            lock_fields.add(k)

    # Frozen entity pack for transparency (visible to LLM but immutable)
    frozen_entities = {
        k: best.get(k)
        for k in [
            "title", "authors", "journal_name", "conference_name",
            "year", "month", "volume", "issue", "pages", "doi"
        ]
        if best.get(k)
    }

    # -----------------------------------------------------------------
    # Prompt design
    # -----------------------------------------------------------------
    prompt = (
        "You are a professional IEEE reference corrector and metadata normalizer.\n"
        "Given the raw reference text, current extracted JSON, and verified fields, "
        "produce a STRICT JSON patch correcting only malformed or missing fields.\n\n"
        "Rules:\n"
        "- Keep factual fields (DOI, year, month, pages, volume, issue) unchanged.\n"
        "- You MAY fix title casing (proper capitalization, acronyms, brands, chemistry symbols), "
        "but do NOT translate, summarize, or rewrite titles.\n"
        "- For authors:\n"
        "  * Restore or include middle initials if missing when known.\n"
        "  * Convert full given names to initials (e.g., 'John Michael Doe' → 'J. M. Doe').\n"
        "  * Preserve non-Western order and compound surnames (e.g., 'van der Waals').\n"
        "  * Maintain IEEE punctuation and spacing (e.g., 'F.M. Lastname').\n"
        "  * Do NOT invent or remove authors.\n"
        "- Preserve acronyms like NLP, DNA, IEEE, GPT-5, CO₂, etc.\n"
        "- If unsure about a field, omit it.\n"
        "- Output JSON ONLY.\n\n"
        f"Raw reference: {ref}\n\n"
        f"Current JSON: {json.dumps(ex, ensure_ascii=False)}\n\n"
        f"Verified (frozen): {json.dumps(frozen_entities, ensure_ascii=False)}\n\n"
        f"Verification flags: {json.dumps(ver)}"
    )

    # -----------------------------------------------------------------
    # LLM invocation
    # -----------------------------------------------------------------
    patch = await llm.json(prompt) or {}

    # Normalize authors, month, and year for consistency
    if isinstance(patch.get("authors"), str):
        patch["authors"] = authors_to_list(patch["authors"])
    if patch.get("month"):
        patch["month"] = normalize_month_field(patch["month"])
    if patch.get("year"):
        patch["year"] = _coerce_year(str(patch["year"]))

    # Validate LLM output schema
    try:
        patch = ExtractedModel(**patch).dict(exclude_none=True)
    except Exception:
        patch = {}

    ex2 = dict(ex)
    changes = []

    # -----------------------------------------------------------------
    # Apply LLM patch to unlocked fields only
    # -----------------------------------------------------------------
    for k, v in patch.items():
        if k in lock_fields:
            continue
        old = ex2.get(k)
        if normalize_text(old) != normalize_text(v) and normalize_text(v):
            ex2[k] = v
            changes.append((k, old, v))

    # Enforce authoritative locks after patch application
    for k in lock_fields:
        bv = best.get(k)
        if k == "year":
            bv = _coerce_year(str(bv))
        if k == "month" and bv:
            bv = normalize_month_field(bv)
        if normalize_text(ex2.get(k)) != normalize_text(bv):
            changes.append((k, ex2.get(k), bv))
            ex2[k] = bv

    # -----------------------------------------------------------------
    # Post-validation: ensure title and authors were not hallucinated
    # -----------------------------------------------------------------
    # ---- Title check ----
    old_title = ex.get("title", "")
    new_title = ex2.get("title", "")
    if old_title and new_title:
        common = set(new_title.lower().split()) & set(old_title.lower().split())
        diff_ratio = len(common) / max(len(old_title.split()), 1)
        if diff_ratio < 0.4:
            ex2["title"] = old_title
            state["_title_flagged_llm_change"] = True

    # ---- Author list check ----
    old_authors = ex.get("authors", [])
    new_authors = ex2.get("authors", [])

    if old_authors and new_authors:
        # Reject if LLM added or dropped too many authors
        if abs(len(new_authors) - len(old_authors)) > 1:
            ex2["authors"] = old_authors
            state["_authors_flagged_llm_change"] = True
        else:
            old_last = {a.split()[-1].lower() for a in old_authors}
            new_last = {a.split()[-1].lower() for a in new_authors}
            if len(old_last & new_last) < len(old_last) * 0.6:
                ex2["authors"] = old_authors
                state["_authors_flagged_llm_change"] = True

    # -----------------------------------------------------------------
    # Commit changes and update fingerprint
    # -----------------------------------------------------------------
    state["extracted"] = ex2
    state["corrections"] = (state.get("corrections") or []) + changes
    state["_made_changes_last_cycle"] = (
        state.get("_made_changes_last_cycle", False) or bool(changes)
    )

    sugg = state.get("suggestions") or {}
    best_now = state.get("best") or {}
    state["_fp"] = fingerprint_state(ex2, best_now, sugg)

    return state
